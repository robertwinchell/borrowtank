﻿
namespace ASOL.HireThings.DAL.Utils
{
    public class CustomSearchParam
    {
        public string ParamName { get; set; }
        public object ParamValue { get; set; }
    }
}
