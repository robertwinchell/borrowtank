﻿
namespace ASOL.HireThings.Model
{
    public class HomeModel : BaseModel, IHomeModel
    {
    }
}
