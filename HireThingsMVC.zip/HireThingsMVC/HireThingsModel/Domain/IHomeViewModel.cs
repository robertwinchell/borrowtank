﻿namespace ASOL.HireThings.Model
{
    public interface IHomeViewModel:IBaseModel
    {
    }
}
