﻿namespace ASOL.HireThings.Model
{
    public interface IHomeModel : IBaseModel
    {
    }
}
