﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
namespace ASOL.HireThings.Model
{
    public class HomeViewModel : BaseModel, IHomeViewModel
    {
    }
}
